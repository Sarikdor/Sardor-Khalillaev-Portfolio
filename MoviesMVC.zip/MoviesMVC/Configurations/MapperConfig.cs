using AutoMapper;
using MoviesMVC.DAL.Models;
using MoviesMVC.DAL.ViewModels;
using MoviesMVC.DAL.ViewModelsWithId;

namespace MoviesMVC.Configurations;

public class MapperConfig : Profile
{
   public MapperConfig()
   {
      CreateMap<ActorViewModel, Actor>();
      CreateMap<ActorViewModelWithId, Actor>();
      CreateMap<CountryViewModel, Country>();
      CreateMap<CountryViewModelWithId, Country>();
      CreateMap<GenreViewModel, Genre>();
      CreateMap<GenreViewModelWithId, Genre>();
      CreateMap<MovieViewModel, Movie>();
      CreateMap<MovieViewModelWithId, Movie>();
      CreateMap<ProducerViewModel, Producer>();
      CreateMap<ProducerViewModelWithId, Producer>();
   }
}