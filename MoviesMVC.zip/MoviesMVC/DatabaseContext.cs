using System.Reflection;
using Microsoft.EntityFrameworkCore;
using MoviesMVC.DAL.Models;

namespace MoviesMVC;

public class DatabaseContext : DbContext
{
    public DbSet<Movie> Movies { get; set; }
    public DbSet<Country> Countries { get; set; }
    public DbSet<Genre> Genres { get; set; }
    public DbSet<Producer> Producers { get; set; }
    public DbSet<Actor> Actors { get; set; }
    public DbSet<MovieActor> MovieActors { get; set; }
    public DbSet<MovieCountry> MovieCountries { get; set; }
    public DbSet<MovieGenre> MovieGenres { get; set; }
    public DbSet<MovieProducer> MovieProducers { get; set; }

    public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
    {
        
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        #region MovieActor Relation

        modelBuilder.Entity<MovieActor>()
            .HasKey(bc => new { bc.ActorId, bc.MovieId });  
        modelBuilder.Entity<MovieActor>()
            .HasOne(bc => bc.Movie)
            .WithMany(b => b.MovieActors)
            .HasForeignKey(bc => bc.ActorId);  
        modelBuilder.Entity<MovieActor>()
            .HasOne(bc => bc.Actor)
            .WithMany(c => c.MovieActors)
            .HasForeignKey(bc => bc.MovieId);

        #endregion
        
        #region MovieCountry Relation

        modelBuilder.Entity<MovieCountry>()
            .HasKey(bc => new { bc.CountryId, bc.MovieId });  
        modelBuilder.Entity<MovieCountry>()
            .HasOne(bc => bc.Movie)
            .WithMany(b => b.MovieCountries)
            .HasForeignKey(bc => bc.CountryId);  
        modelBuilder.Entity<MovieCountry>()
            .HasOne(bc => bc.Country)
            .WithMany(c => c.MovieCountries)
            .HasForeignKey(bc => bc.MovieId);

        #endregion
        
        #region MovieGenre Relation

        modelBuilder.Entity<MovieGenre>()
            .HasKey(bc => new { bc.GenreId, bc.MovieId });  
        modelBuilder.Entity<MovieGenre>()
            .HasOne(bc => bc.Movie)
            .WithMany(b => b.MovieGenres)
            .HasForeignKey(bc => bc.GenreId);  
        modelBuilder.Entity<MovieGenre>()
            .HasOne(bc => bc.Genre)
            .WithMany(c => c.MovieGenres)
            .HasForeignKey(bc => bc.MovieId);

        #endregion
        
        #region MovieCountry Relation

        modelBuilder.Entity<MovieProducer>()
            .HasKey(bc => new { bc.ProducerId, bc.MovieId });  
        modelBuilder.Entity<MovieProducer>()
            .HasOne(bc => bc.Movie)
            .WithMany(b => b.MovieProducers)
            .HasForeignKey(bc => bc.ProducerId);  
        modelBuilder.Entity<MovieProducer>()
            .HasOne(bc => bc.Producer)
            .WithMany(c => c.MovieProducers)
            .HasForeignKey(bc => bc.MovieId);

        #endregion
        
        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }
}