using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.ViewModels;

public class CountryViewModel
{
    public string Name { get; set; }

    public virtual IList<Movie> Movies { get; set; } = new List<Movie>();
    public virtual IList<Actor> Actors { get; set; } = new List<Actor>();
    public virtual IList<Producer> Producers { get; set; } = new List<Producer>();
}