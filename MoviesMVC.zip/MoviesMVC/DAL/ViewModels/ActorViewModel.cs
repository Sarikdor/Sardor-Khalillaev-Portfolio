using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.ViewModels;

public class ActorViewModel
{
    public string Name { get; set; }
    public DateOnly DateOfBirth { get; set; }
    public string About { get; set; }
    public string CountryOfBirth { get; set; }
    
    public virtual Country Country { get; set; }
    public virtual IList<Movie> Movies { get; set; }
}