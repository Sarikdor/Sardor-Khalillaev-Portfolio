using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.ViewModels;

public class GenreViewModel
{
    public string Name { get; set; }

    public virtual IList<Movie> Movies { get; set; } = new List<Movie>();
}