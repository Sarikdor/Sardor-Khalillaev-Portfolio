using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.ViewModels;

public class MovieViewModel
{
    public string Title { get; set; }
    public DateOnly ReleaseDate { get; set; }
    public string Description { get; set; }
    public short Rating { get; set; }

    public virtual IList<Country> Countries { get; set; } = new List<Country>();
    public virtual IList<Genre> Genres { get; set; } = new List<Genre>();
    public virtual IList<Producer> Producers { get; set; } = new List<Producer>();
    public virtual IList<Actor> Actors { get; set; } = new List<Actor>();
}