using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MoviesMVC.DAL.Constants;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.EntityTypeConfigurations;

public class MovieEntityTypeConfiguration : IEntityTypeConfiguration<Movie>
{
    public void Configure(EntityTypeBuilder<Movie> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("Movie");

        entityTypeBuilder.HasKey(k => k.Id).HasName("PK_Movie");

        entityTypeBuilder.Property(p => p.Id).HasColumnType(StringConstants.Int).UseMySqlIdentityColumn();
        entityTypeBuilder.Property(p => p.Title).HasColumnType(StringConstants.Varchar20).IsRequired();
        entityTypeBuilder.Property(p => p.ReleaseDate).HasColumnType(StringConstants.Date).IsRequired();
        entityTypeBuilder.Property(p => p.Description).HasColumnType(StringConstants.Varchar400).IsRequired();
        entityTypeBuilder.Property(p => p.Rating).HasColumnType(StringConstants.Float).IsRequired();
        
        
    }
}