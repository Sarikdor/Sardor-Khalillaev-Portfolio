using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.EntityTypeConfigurations;

public class MovieActorEntityTypeConfiguration : IEntityTypeConfiguration<MovieActor>
{
    public void Configure(EntityTypeBuilder<MovieActor> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("MovieActor");

        // entityTypeBuilder
        //     .HasOne(p => p.Movie)
        //     .WithMany(opt => opt.Actors)
        //     .HasForeignKey(p => p.MovieId).IsRequired();
        //
        // entityTypeBuilder
        //     .HasOne(p => p.Actor)
        //     .WithMany(opt => opt.Movies)
        //     .HasForeignKey(p => p.ActorId).IsRequired();
        
        
    }
        
    
    
    
    
    
    
    
    
    // protected override void Configure(ModelBuilder modelBuilder)
    // {
    //     modelBuilder.Entity<MovieActor>()
    //         .HasKey(bc => new { bc.ActorId, bc.MovieId });  
    //     modelBuilder.Entity<MovieActor>()
    //         .HasOne(bc => bc.Movie)
    //         .WithMany(b => b.MovieActor)
    //         .HasForeignKey(bc => bc.BookId);  
    //     modelBuilder.Entity<MovieActor>()
    //         .HasOne(bc => bc.Movie)
    //         .WithMany(c => c.MovieActor)
    //         .HasForeignKey(bc => bc.CategoryId);
    //     
    //     
    // }
}