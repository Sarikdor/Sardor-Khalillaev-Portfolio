namespace MoviesMVC.DAL.EntityTypeConfigurations;

public class MovieCountryEntityTypeConfiguration
{
    
}