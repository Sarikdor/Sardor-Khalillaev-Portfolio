using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MoviesMVC.DAL.Constants;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.EntityTypeConfigurations;

public class GenreEntityTypeConfiguration : IEntityTypeConfiguration<Genre>
{
    public void Configure(EntityTypeBuilder<Genre> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("Genre");

        entityTypeBuilder.HasKey(k => k.Id).HasName("PK_Genre");

        entityTypeBuilder.Property(p => p.Id).HasColumnType(StringConstants.Int).UseMySqlIdentityColumn();
        entityTypeBuilder.Property(p => p.Name).HasColumnType(StringConstants.Varchar10).IsRequired();
        
        // Many to Many connection
    }
}