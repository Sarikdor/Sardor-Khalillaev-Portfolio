namespace MoviesMVC.DAL.EntityTypeConfigurations;

public class MovieProducerEntityTypeConfiguration
{
    
}