using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MoviesMVC.DAL.Constants;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.EntityTypeConfigurations;

public class CountryEntityTypeConfiguration : IEntityTypeConfiguration<Country>
{
    public void Configure(EntityTypeBuilder<Country> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("Country");

        entityTypeBuilder.HasKey(k => k.Id).HasName("PK_Country");

        entityTypeBuilder.Property(p => p.Id).HasColumnType(StringConstants.Int).UseMySqlIdentityColumn();
        entityTypeBuilder.Property(p => p.Name).IsRequired();

        entityTypeBuilder
            .HasMany(opt => opt.Actors)
            .WithOne(opt => opt.Country)
            .HasForeignKey(opt => opt.CountryOfBirthId);
        
        entityTypeBuilder
            .HasMany(opt => opt.Producers)
            .WithOne(opt => opt.Country)
            .HasForeignKey(opt => opt.CountryOfBirthId);
        
        // Many to Many Connection
    }
}