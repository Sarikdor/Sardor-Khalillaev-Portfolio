using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MoviesMVC.DAL.Constants;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.EntityTypeConfigurations;

public class ActorEntityTypeConfiguration : IEntityTypeConfiguration<Actor>
{
    public void Configure(EntityTypeBuilder<Actor> entityTypeBuilder)
    {
        entityTypeBuilder.ToTable("Actors");

        entityTypeBuilder.HasKey(k => k.Id).HasName("PK_Actor");

        entityTypeBuilder.Property(p => p.Id).HasColumnType(StringConstants.Int).UseMySqlIdentityColumn();
        entityTypeBuilder.Property(p => p.Name).HasColumnType(StringConstants.Varchar20).IsRequired();
        entityTypeBuilder.Property(p => p.DateOfBirth).HasColumnType(StringConstants.Date).IsRequired();
        entityTypeBuilder.Property(p => p.About).HasColumnType(StringConstants.Varchar400).IsRequired();


        entityTypeBuilder
            .HasOne(opt => opt.Country)
            .WithMany(opt => opt.Actors)
            .HasForeignKey(opt => opt.CountryOfBirthId);
        
        // Many to Many
        

        
    }
}