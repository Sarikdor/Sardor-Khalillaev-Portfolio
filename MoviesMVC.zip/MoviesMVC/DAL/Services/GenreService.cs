using Microsoft.EntityFrameworkCore;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.Services;

public partial class DatabaseService
{
    #region Get

    public async Task<IEnumerable<Genre>> GetGenresAsync()
    {
        return await _context.Genres
            .Include(e => e.MovieGenres)
            .ToListAsync();

    }
    public async Task<IEnumerable<Genre>> GetGenreByNameAsync(string name)
    {
        return await _context.Genres
            .Include(e => e.MovieGenres)    
            .Where(e => e.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
            .ToListAsync(); 
    }
    public async Task<Genre> GetGenreAsync(int id)
    {
        return await _context.Genres
            .Include(e => e.MovieGenres)
            .FirstOrDefaultAsync(e => e.Id == id);
    }

    #endregion
    
    #region Add

    public async Task<int> AddGenreAsync(Genre genre)
    {
        await _context.Genres.AddAsync(genre);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddGenresAsync(IEnumerable<Genre> genres)
    {
        await _context.Genres.AddRangeAsync(genres);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateGenreAsync(Genre genre)
    {
        _context.Genres.Update(genre);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateGenresAsync(IEnumerable<Genre> genres)
    {
        _context.Genres.UpdateRange(genres);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Delete

    public async Task<int> RemoveGenreAsync(Genre genre)
    {
        _context.Genres.Remove(genre);
        return await _context.SaveChangesAsync();

    }
    public async Task<int> RemoveGenresAsync(IEnumerable<Genre> genres)
    {
        _context.Genres.RemoveRange(genres);
        return await _context.SaveChangesAsync();
    }
    
    public async Task<int> RemoveGenreByIdAsync(int id)
    {
        var resGenres = _context.Genres.FirstOrDefault(e => e.Id == id);
        if (resGenres is null)
        {
            return default;
        }
        _context.Genres.Remove(resGenres);
        return await _context.SaveChangesAsync();
    }
                    
    public async Task<int> RemoveGenreByNameAsync(string name)
    {
        var resGenre = _context.Genres.FirstOrDefault(e => e.Name.Equals(name));
        if (resGenre is null)
        {
            return default;
        }
        _context.Genres.Remove(resGenre);
        return await _context.SaveChangesAsync();
    }

    #endregion
}