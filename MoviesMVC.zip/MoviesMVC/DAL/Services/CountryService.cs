using System.Collections;
using Microsoft.EntityFrameworkCore;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.Services;

public partial class DatabaseService
{
    #region Get

    public async Task<IEnumerable<Country>> GetCountrysAsync()
    {
        return await _context.Countries
            .Include(e => e.MovieCountries)
            .ToListAsync();

    }

    public async Task<IEnumerable<Country>> GetCountryByNameAsync(string name)
    {
        return await _context.Countries
            .Include(e => e.MovieCountries)    
            .Where(e => e.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
            .ToListAsync(); 
    }

    public async Task<Country> GetcounbtryAsync(int id)
    {
        return await _context.Countries
            .Include(e => e.MovieCountries)
            .FirstOrDefaultAsync(e => e.Id == id);
    }

    #endregion
    
    #region Add

    public async Task<int> AddCountryAsync(Country country)
    {
        await _context.Countries.AddAsync(country);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddCountriesAsync(IEnumerable<Country> countries)
    {
        await _context.Countries.AddRangeAsync(countries);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateCountryAsync(Country country)
    {
         _context.Countries.Update(country);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateCountriesAsync(IEnumerable<Country> countries)
    {
         _context.Countries.UpdateRange(countries);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Delete

    public async Task<int> RemoveCountryAsync(Country country)
    {
        _context.Countries.Remove(country);
        return await _context.SaveChangesAsync();

    }
    public async Task<int> RemoveCountriesAsync(IEnumerable<Country> countries)
    {
        _context.Countries.RemoveRange(countries);
        return await _context.SaveChangesAsync();
    }
    
    public async Task<int> RemoveCountryByIdAsync(int id)
    {
        var resCountry = _context.Countries.FirstOrDefault(e => e.Id == id);
        if (resCountry is null)
        {
            return default;
        }
        _context.Countries.Remove(resCountry);
        return await _context.SaveChangesAsync();
    }
                    
    public async Task<int> RemoveCountryByNameAsync(string name)
    {
        var resCountry = _context.Countries.FirstOrDefault(e => e.Name.Equals(name));
        if (resCountry is null)
        {
            return default;
        }
        _context.Countries.Remove(resCountry);
        return await _context.SaveChangesAsync();
    }

    #endregion
}
