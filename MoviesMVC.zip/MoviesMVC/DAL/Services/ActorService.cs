using System.Collections;
using Microsoft.EntityFrameworkCore;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.Services;

public partial class DatabaseService
{
    #region Get

        public async Task<IEnumerable<Actor>> GetActorsAsync()
        {
            return await _context.Actors
                .Include(e => e.Movies)
                .Include(e => e.Country)
                .Include(e => e.MovieActors)
                .ToListAsync();
        }

        public async Task<IEnumerable<Actor>> GetactorsByNameAsync(string name)
        {
            return await _context.Actors
                .Include(e => e.Movies)
                .Include(e => e.Country)
                .Include(e => e.MovieActors)
                .Where(e => e.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
                .ToListAsync(); 
        }

        public async Task<Actor> GetActorAsync(int id)
        {
            return await _context.Actors
                .Include(e => e.Movies)
                .Include(e => e.Country)
                .Include(e => e.MovieActors)
                .FirstOrDefaultAsync(e => e.Id == id);
        }

    #endregion
    
    #region Add

    public async Task<int> AddActorAsync(Actor actor)
    {
        await _context.Actors.AddAsync(actor);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddActorsAsync(IEnumerable<Actor> actors)
    {
        await _context.Actors.AddRangeAsync(actors);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateActorAsync(Actor actor)
    {
         _context.Actors.Update(actor);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateActorsAsync(IEnumerable<Actor> actors)
    {
         _context.Actors.UpdateRange(actors);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Delete

    public async Task<int> RemoveActorAsync(Actor actor)
    {
        _context.Actors.Remove(actor);
        return await _context.SaveChangesAsync();

    }
    public async Task<int> RemoveActorsAsync(IEnumerable<Actor> actors)
    {
        _context.Actors.RemoveRange(actors);
        return await _context.SaveChangesAsync();
    }
    
    public async Task<int> RemoveActorByIdAsync(int id)
    {
        var resStudent = _context.Actors.FirstOrDefault(e => e.Id == id);
        if (resStudent is null)
        {
            return default;
        }
        _context.Actors.Remove(resStudent);
        return await _context.SaveChangesAsync();
    }
                    
    public async Task<int> RemoveActorByNameAsync(string name)
    {
        var resActor = _context.Actors.FirstOrDefault(e => e.Name.Equals(name));
        if (resActor is null)
        {
            return default;
        }
        _context.Actors.Remove(resActor);
        return await _context.SaveChangesAsync();
    }

   
    #endregion
}