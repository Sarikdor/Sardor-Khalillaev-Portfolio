using Microsoft.EntityFrameworkCore;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.Services;

public partial class DatabaseService
{
    #region Get

    public async Task<IEnumerable<Producer>> GetProducersAsync()
    {
        return await _context.Producers
            .Include(e => e.Movies)
            .Include(e => e.Country)
            .Include(e => e.MovieProducers)
            .ToListAsync();
    }

    public async Task<IEnumerable<Producer>> GetProducersByNameAsync(string name)
    {
        return await _context.Producers
            .Include(e => e.Movies)
            .Include(e => e.Country)
            .Include(e => e.MovieProducers)
            .Where(e => e.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
            .ToListAsync(); 
    }

    public async Task<Producer> GetProducerAsync(int id)
    {
        return await _context.Producers
            .Include(e => e.Movies)
            .Include(e => e.Country)
            .Include(e => e.MovieProducers)
            .FirstOrDefaultAsync(e => e.Id == id);
    }

    #endregion
    
    #region Add

    public async Task<int> AddProducerAsync(Producer producer)
    {
        await _context.Producers.AddAsync(producer);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddProducersAsync(IEnumerable<Producer> producers)
    {
        await _context.Producers.AddRangeAsync(producers);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateProducerAsync(Producer producer)
    {
         _context.Producers.Update(producer);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateProducersAsync(IEnumerable<Producer> producers)
    {
         _context.Producers.UpdateRange(producers);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Delete

    public async Task<int> RemoveProducerAsync(Producer producer)
    {
        _context.Producers.Remove(producer);
        return await _context.SaveChangesAsync();

    }
    public async Task<int> RemoveProducersAsync(IEnumerable<Producer> producers)
    {
        _context.Producers.RemoveRange(producers);
        return await _context.SaveChangesAsync();
    }
    
    public async Task<int> RemoveProducerByIdAsync(int id)
    {
        var resProducer = _context.Producers.FirstOrDefault(e => e.Id == id);
        if (resProducer is null)
        {
            return default;
        }
        _context.Producers.Remove(resProducer);
        return await _context.SaveChangesAsync();
    }
                    
    public async Task<int> RemoveProducerByNameAsync(string name)
    {
        var resProducer = _context.Producers.FirstOrDefault(e => e.Name.Equals(name));
        if (resProducer is null)
        {
            return default;
        }
        _context.Producers.Remove(resProducer);
        return await _context.SaveChangesAsync();
    }

    #endregion
}