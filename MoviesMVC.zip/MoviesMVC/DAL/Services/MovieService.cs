using Microsoft.EntityFrameworkCore;
using MoviesMVC.DAL.Models;

namespace MoviesMVC.DAL.Services;

public partial class DatabaseService
{
    #region Get

    public async Task<IEnumerable<Movie>> GetMoviesAsync()
    {
        return await _context.Movies
            .Include(e => e.MovieActors)
            .Include(e => e.MovieCountries)
            .Include(e => e.MovieProducers)
            .Include(e => e.MovieGenres)
            .ToListAsync();
    }

    public async Task<IEnumerable<Movie>> GetMoviesByNameAsync(string title)
    {
        return await _context.Movies
            .Include(e => e.MovieActors)
            .Include(e => e.MovieCountries)
            .Include(e => e.MovieProducers)
            .Include(e => e.MovieGenres)
            .Where(e => e.Title.Contains(title, StringComparison.OrdinalIgnoreCase))
            .ToListAsync(); 
    }

    public async Task<Movie> GetMovieAsync(int id)
    {
        return await _context.Movies
            .Include(e => e.MovieActors)
            .Include(e => e.MovieCountries)
            .Include(e => e.MovieProducers)
            .Include(e => e.MovieGenres)
            .FirstOrDefaultAsync(e => e.Id == id);
    }

    #endregion
    
    #region Add

    public async Task<int> AddMovieAsync(Movie movie)
    {
        await _context.Movies.AddAsync(movie);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> AddMoviesAsync(IEnumerable<Movie> movies)
    {
        await _context.Movies.AddRangeAsync(movies);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Update

    public async Task<int> UpdateMovieAsync(Movie movie)
    {
         _context.Movies.Update(movie);
        return await _context.SaveChangesAsync();
    }

    public async Task<int> UpdateMoviesAsync(IEnumerable<Movie> movies)
    {
        _context.Movies.UpdateRange(movies);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    #region Delete

    public async Task<int> RemoveMovieAsync(Movie movie)
    {
        _context.Movies.Remove(movie);
        return await _context.SaveChangesAsync();

    }
    public async Task<int> RemoveMoviesAsync(IEnumerable<Movie> movies)
    {
        _context.Movies.RemoveRange(movies);
        return await _context.SaveChangesAsync();
    }
    
    public async Task<int> RemoveMovieByIdAsync(int id)
    {
        var resMovie = _context.Movies.FirstOrDefault(e => e.Id == id);
        if (resMovie is null)
        {
            return default;
        }
        _context.Movies.Remove(resMovie);
        return await _context.SaveChangesAsync();
    }
                    
    public async Task<int> RemoveMovieByNameAsync(string title)
    {
        var resMovie = _context.Movies.FirstOrDefault(e => e.Title.Equals(title));
        if (resMovie is null)
        {
            return default;
        }
        _context.Movies.Remove(resMovie);
        return await _context.SaveChangesAsync();
    }

    #endregion
    
    
}