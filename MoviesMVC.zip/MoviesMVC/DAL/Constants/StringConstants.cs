namespace MoviesMVC.DAL.Constants;

public class StringConstants
{
    internal const string Int = "int";
    internal const string Float = "float(10)";
    internal const string Date = "date";
    internal const string Varchar10 = "varchar(10)";
    internal const string Varchar20 = "varchar(20)";
    internal const string Varchar400 = "varchar(400)";
}