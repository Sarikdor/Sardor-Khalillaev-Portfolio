namespace MoviesMVC.DAL.ViewModelsWithId;

public class MovieViewModelWithId
{
    public int Id { get; set; }
    public string Title { get; set; }
    public DateOnly ReleaseDate { get; set; }
    public string Description { get; set; }
    public short Rating { get; set; }
}