namespace MoviesMVC.DAL.ViewModelsWithId;

public class CountryViewModelWithId
{
    public int Id { get; set; }
    public string Name { get; set; }
}