namespace MoviesMVC.DAL.ViewModelsWithId;

public class GenreViewModelWithId
{
    public int Id { get; set; }
    public string Name { get; set; }
}