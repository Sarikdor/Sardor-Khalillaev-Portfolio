namespace MoviesMVC.DAL.ViewModelsWithId;

public class ProducerViewModelWithId
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateOnly DateOfBirth { get; set; }
    public string About { get; set; }
    public int CountryOfBirthId { get; set; }
}