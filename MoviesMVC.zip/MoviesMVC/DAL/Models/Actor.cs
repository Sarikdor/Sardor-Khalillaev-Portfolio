namespace MoviesMVC.DAL.Models;

public class Actor
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateOnly DateOfBirth { get; set; }
    public string About { get; set; }
    public int CountryOfBirthId { get; set; }
    
    public virtual Country Country { get; set; }
    
    public virtual IEnumerable<Movie> Movies { get; set; }
    
    public  IEnumerable<MovieActor> MovieActors { get; set; }

}