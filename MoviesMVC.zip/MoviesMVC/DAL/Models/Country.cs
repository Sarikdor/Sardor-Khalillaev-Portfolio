using System.Collections;

namespace MoviesMVC.DAL.Models;

public class Country
{
    public int Id { get; set; }
    public string Name { get; set; }

    public virtual IEnumerable<Movie> Movies { get; set; } = new List<Movie>();
    public virtual IEnumerable<Actor> Actors { get; set; } = new List<Actor>();
    public virtual  IEnumerable<Producer> Producers { get; set; } = new List<Producer>();
    
    public IEnumerable<MovieCountry> MovieCountries { get; set; }

}