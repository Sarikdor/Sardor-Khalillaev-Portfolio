using System.Collections;

namespace MoviesMVC.DAL.Models;

public class Movie
{
    public int Id { get; set; }
    public string Title { get; set; }
    public DateOnly ReleaseDate { get; set; }
    public string Description { get; set; }
    public short Rating { get; set; }

    // public virtual IEnumerable<Country> Countries { get; set; } = new List<Country>();
    // public virtual IEnumerable<Genre> Genres { get; set; } = new List<Genre>();
    // public virtual IEnumerable<Producer> Producers { get; set; } = new List<Producer>();
    // public virtual IEnumerable<Actor> Actors { get; set; } = new List<Actor>();
    
    public IEnumerable<MovieActor> MovieActors { get; set; } 
    public IEnumerable<MovieGenre> MovieGenres { get; set; }
    public IEnumerable<MovieCountry> MovieCountries { get; set; }
    public IEnumerable<MovieProducer> MovieProducers { get; set; }
}