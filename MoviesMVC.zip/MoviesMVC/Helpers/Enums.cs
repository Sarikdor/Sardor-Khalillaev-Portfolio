namespace MoviesMVC.Helpers;

public enum SortState
{
    IdAsc,
    IdDesc,
    NameAsc, 
    NameDesc,
    CountryAsc,
    CountryDesc,
    DateOfBirthAsc,
    DateOfBirthDesc,
    RatingAsc,
    RatingDesc,
    DescriptionAsc,
    DescriptionDesc,
    ReleaseDateAsc,
    ReleaseDateDesc,
    TitleAsc,
    TitleDesc,
    AboutAsc,
    AboutDesc

}