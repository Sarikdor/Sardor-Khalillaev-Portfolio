using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using MoviesMVC.DAL.Models;
using MoviesMVC.DAL.Services;
using MoviesMVC.DAL.ViewModels;
using MoviesMVC.DAL.ViewModelsWithId;
using MoviesMVC.Helpers;

namespace MoviesMVC.Controllers;
[ApiController]
[Route("api/[controller]")]
public class ProducerController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public ProducerController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }
    
    #region Get

    // [Route("GetProducers")]
    // [HttpGet]
    // public async Task<IEnumerable<Producer>> GetProducer()
    // {
    //     return await _databaseService.GetProducersAsync();
    // }
    //
    // [Route("GetProducer/{id}")]
    // [HttpGet]
    // public async Task<Producer> GetProducer(int id)
    // {
    //     return await _databaseService.GetProducerAsync(id);
    // }
    //
    // [Route("GetProducerByName/{name}")]
    // [HttpGet]
    // public async Task<IEnumerable<Producer>> GetProdcer(string name)
    // {
    //     return await _databaseService.GetProducersByNameAsync(name);
    // }
    [Route("GetProducers")]
    [HttpGet]
    public async Task<IActionResult> GetProducers(SortState sortOrder = SortState.NameAsc)
    {
        var producers = await _databaseService.GetProducersAsync();
        ViewData["IdSort"] = sortOrder == SortState.IdAsc ? SortState.IdDesc : SortState.IdAsc;
        ViewData["NameSort"] = sortOrder == SortState.NameAsc ? SortState.NameDesc : SortState.NameAsc;
        ViewData["CountrySort"] = sortOrder == SortState.CountryAsc ? SortState.CountryDesc : SortState.CountryAsc;
       
        producers = sortOrder switch
        {
            SortState.IdAsc => producers.OrderBy(s => s.Id),
            SortState.IdDesc => producers.OrderByDescending(s => s.Id),
            SortState.NameAsc => producers.OrderBy(s => s.Name),
            SortState.NameDesc => producers.OrderByDescending(s => s.Name),
            SortState.CountryAsc => producers.OrderBy(s => s.Country),
            SortState.CountryDesc => producers.OrderByDescending(s => s.Country),
            
            _ => producers.OrderBy(s => s.Id)
        };
        return View("~/Views/Producer/Producers.cshtml",producers.ToList());
    }
    #endregion
    
    #region Add

    [Route("AddProducer")]
    [HttpPost]
    public async Task<IActionResult> AddProducer(ProducerViewModel producerViewModel)
    {
        var producer = _mapper.Map<Producer>(producerViewModel);
        var result = await _databaseService.AddProducerAsync(producer);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("AddProducers")]
    [HttpPost]
    public async Task<IActionResult> AddActors(IEnumerable<ProducerViewModel> producerViewModels)
    {
        var producers = _mapper.Map<IEnumerable<Actor>>(producerViewModels);
        var result = await _databaseService.AddActorsAsync(producers);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Update

    [Route("UpdateProducer")]
    [HttpPost]
    public async Task<IActionResult> UpdateProducer(ProducerViewModelWithId producerViewModelWithId)
    {
        var producer = _mapper.Map<Producer>(producerViewModelWithId);
        var result = await _databaseService.UpdateProducerAsync(producer);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("UpdateProducers")]
    [HttpPost]
    public async Task<IActionResult> UpdateProducers(IEnumerable<ProducerViewModelWithId> producerViewModelWithIds)
    {
        var producers = _mapper.Map<IEnumerable<Producer>>(producerViewModelWithIds);
        var result = await _databaseService.UpdateProducersAsync(producers);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Delete

    [Route("DeleteProducer")]
    [HttpPost]
    public async Task<IActionResult> DeleteProducer(ProducerViewModel producerViewModel)
    {
        var producer = _mapper.Map<Producer>(producerViewModel);
        var result = await _databaseService.RemoveProducerAsync(producer);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("DeleteProducers")]
    [HttpPost]
    public async Task<IActionResult> DeleteProducers(IEnumerable<ProducerViewModel> producerViewModels)
    {
        var producers = _mapper.Map<IEnumerable<Producer>>(producerViewModels);
        var result = await _databaseService.RemoveProducersAsync(producers);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
}