using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using MoviesMVC.DAL.Models;
using MoviesMVC.DAL.Services;
using MoviesMVC.DAL.ViewModels;
using MoviesMVC.DAL.ViewModelsWithId;

namespace MoviesMVC.Controllers;
[ApiController]
[Route("api/[controller]")]

public class CountryController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public CountryController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }
    
    #region Get

    [Route("GetCountries")]
    [HttpGet]
    public async Task<IEnumerable<Country>> GetCountries()
    {
        return await _databaseService.GetCountrysAsync();
    }

    [Route("GetCountry/{id}")]
    [HttpGet]
    public async Task<Country> GetCountry(int id)
    {
        return await _databaseService.GetcounbtryAsync(id);
    }
    [Route("GetCountryByName/{name}")]
    [HttpGet]
    public async Task<IEnumerable<Country>> GetCountry(string name)
    {
        return await _databaseService.GetCountryByNameAsync(name);
    }
    #endregion
    
    #region Add

    [Route("AddCountry")]
    [HttpPost]
    public async Task<IActionResult> AddCountry(CountryViewModel countryViewModel)
    {
        var country = _mapper.Map<Country>(countryViewModel);
        var result = await _databaseService.AddCountryAsync(country);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("AddCountries")]
    [HttpPost]
    public async Task<IActionResult> AddCountries(IEnumerable<CountryViewModel> countryViewModels)
    {
        var countries = _mapper.Map<IEnumerable<Country>>(countryViewModels);
        var result = await _databaseService.AddCountriesAsync(countries);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Update

    [Route("UpdateCountry")]
    [HttpPost]
    public async Task<IActionResult> UpdateCountry(CountryViewModelWithId countryViewModelWithId)
    {
        var country = _mapper.Map<Country>(countryViewModelWithId);
        var result = await _databaseService.UpdateCountryAsync(country);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("UpdateCountries")]
    [HttpPost]
    public async Task<IActionResult> UpdateActors(IEnumerable<CountryViewModelWithId> countryViewModelWithIds)
    {
        var countries = _mapper.Map<IEnumerable<Country>>(countryViewModelWithIds);
        var result = await _databaseService.UpdateCountriesAsync(countries);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Delete
    [Route("DeleteCountry")]
    [HttpPost]
    public async Task<IActionResult> DeleteCountry(CountryViewModel countryViewModel)
    {
        var country = _mapper.Map<Country>(countryViewModel);
        var result = await _databaseService.RemoveCountryAsync(country);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("DeleteCountries")]
    [HttpPost]
    public async Task<IActionResult> DeleteCountries(IEnumerable<CountryViewModel> countryViewModels )
    {
        var countries = _mapper.Map<IEnumerable<Country>>(countryViewModels);
        var result = await _databaseService.RemoveCountriesAsync(countries);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }


    #endregion
   
}