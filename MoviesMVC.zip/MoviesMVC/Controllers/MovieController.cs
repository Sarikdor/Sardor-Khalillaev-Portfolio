using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using MoviesMVC.DAL.Models;
using MoviesMVC.DAL.Services;
using MoviesMVC.DAL.ViewModels;
using MoviesMVC.DAL.ViewModelsWithId;
using MoviesMVC.Helpers;

namespace MoviesMVC.Controllers;
[ApiController]
[Route("api/[controller]")]
public class MovieController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public MovieController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }
    
    #region Get

    // [Route("GetMovies")]
    // [HttpGet]
    // public async Task<IEnumerable<Movie>> GetActors()
    // {
    //     return await _databaseService.GetMoviesAsync();
    // }
    //
    // [Route("GetMovie/{id}")]
    // [HttpGet]
    // public async Task<Movie> GetActor(int id)
    // {
    //     return await _databaseService.GetMovieAsync(id);
    // }
    // [Route("GetMovieByName/{name}")]
    // [HttpGet]
    // public async Task<IEnumerable<Movie>> GetMovie(string name)
    // {
    //     return await _databaseService.GetMoviesByNameAsync(name);
    // }
    [Route("GetMovies")]
    [HttpGet]
    public async Task<IActionResult> GetMovies(SortState sortOrder = SortState.NameAsc)
    {
        var movies = await _databaseService.GetMoviesAsync();
        ViewData["IdSort"] = sortOrder == SortState.IdAsc ? SortState.IdDesc : SortState.IdAsc;
        ViewData["TitleSort"] = sortOrder == SortState.TitleAsc ? SortState.TitleDesc : SortState.TitleAsc;
        ViewData["CountrySort"] = sortOrder == SortState.CountryAsc ? SortState.CountryDesc : SortState.CountryAsc;
        ViewData["RatingSort"] = sortOrder == SortState.RatingAsc ? SortState.RatingDesc : SortState.RatingAsc;
        ViewData["ReleaseDateSort"] = sortOrder == SortState.ReleaseDateAsc ? SortState.ReleaseDateDesc : SortState.ReleaseDateAsc;
        
        
        
        movies = sortOrder switch
        {
            SortState.IdAsc => movies.OrderBy(s => s.Id),
            SortState.IdDesc => movies.OrderByDescending(s => s.Id),
            SortState.TitleAsc => movies.OrderBy(s => s.Title),
            SortState.TitleDesc => movies.OrderByDescending(s => s.Title),
            SortState.ReleaseDateAsc => movies.OrderBy(s => s.ReleaseDate),
            SortState.ReleaseDateDesc => movies.OrderByDescending(s => s.ReleaseDate),
            SortState.RatingAsc => movies.OrderBy(s => s.Rating),
            SortState.RatingDesc => movies.OrderByDescending(s => s.Rating),
            _ => movies.OrderBy(s => s.Id)
        };
        return View("~/Views/Movie/Movies.cshtml",movies.ToList());
    }
    #endregion
    
    #region Add

    [Route("AddMovie")]
    [HttpPost]
    public async Task<IActionResult> AddMovies(MovieViewModel movieViewModel)
    {
        var movie = _mapper.Map<Movie>(movieViewModel);
        var result = await _databaseService.AddMovieAsync(movie);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("AddMovies")]
    [HttpPost]
    public async Task<IActionResult> AddMovies(IEnumerable<MovieViewModel> movieViewModels)
    {
        var movies = _mapper.Map<IEnumerable<Movie>>(movieViewModels);
        var result = await _databaseService.AddMoviesAsync(movies);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Update

    [Route("UpdateMovie")]
    [HttpPost]
    public async Task<IActionResult> UpdateMovie(MovieViewModelWithId movieViewModelWithId)
    {
        var movie = _mapper.Map<Movie>(movieViewModelWithId);
        var result = await _databaseService.UpdateMovieAsync(movie);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("UpdateMovies")]
    [HttpPost]
    public async Task<IActionResult> UpdateActors(IEnumerable<MovieViewModelWithId> movieViewModelWithIds)
    {
        var movies = _mapper.Map<IEnumerable<Movie>>(movieViewModelWithIds);
        var result = await _databaseService.UpdateMoviesAsync(movies);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Delete

    [Route("DeleteMovie")]
    [HttpPost]
    public async Task<IActionResult> DeleteMovie(MovieViewModel movieViewModel)
    {
        var movie = _mapper.Map<Movie>(movieViewModel);
        var result = await _databaseService.RemoveMovieAsync(movie);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("DeleteMovies")]
    [HttpPost]
    public async Task<IActionResult> DeleteMovies(IEnumerable<MovieViewModel> movieViewModels)
    {
        var movies = _mapper.Map<IEnumerable<Movie>>(movieViewModels);
        var result = await _databaseService.RemoveMoviesAsync(movies);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
}