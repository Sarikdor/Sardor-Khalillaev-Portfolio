using System.Collections;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using MoviesMVC.DAL.Models;
using MoviesMVC.DAL.Services;
using MoviesMVC.DAL.ViewModels;
using MoviesMVC.DAL.ViewModelsWithId;
using MoviesMVC.Helpers;

namespace MoviesMVC.Controllers;
[ApiController]
[Route("api/[controller]")]
public class ActorController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public ActorController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }

    #region Get

    [Route("GetActors")]
    [HttpGet]
    public async Task<IActionResult> GetActors(SortState sortOrder = SortState.NameAsc)
    {
        var actors = await _databaseService.GetActorsAsync();
        ViewData["IdSort"] = sortOrder == SortState.IdAsc ? SortState.IdDesc : SortState.IdAsc;
        ViewData["NameSort"] = sortOrder == SortState.NameAsc ? SortState.NameDesc : SortState.NameAsc;
        ViewData["CountrySort"] = sortOrder == SortState.CountryAsc ? SortState.CountryDesc : SortState.CountryAsc;
        ViewData["DateOfBirthSort"] = sortOrder == SortState.DateOfBirthAsc ? SortState.DateOfBirthDesc : SortState.DateOfBirthAsc;

        actors = sortOrder switch
        {
            SortState.IdAsc => actors.OrderBy(s => s.Id),
            SortState.IdDesc => actors.OrderByDescending(s => s.Id),
            SortState.NameAsc => actors.OrderBy(s => s.Name),
            SortState.NameDesc => actors.OrderByDescending(s => s.Name),
            SortState.CountryAsc => actors.OrderBy(s => s.Country),
            SortState.CountryDesc => actors.OrderByDescending(s => s.Country),
            SortState.DateOfBirthAsc => actors.OrderBy(s => s.DateOfBirth),
            SortState.DateOfBirthDesc => actors.OrderByDescending(s => s.DateOfBirth),
            _ => actors.OrderBy(s => s.Id)
        };
        return View("~/Views/Actor/Actors.cshtml",actors.ToList());
    }

        // public async Task<IEnumerable<Actor>> GetActors()
    // {
    //     return await _databaseService.GetActorsAsync();
    // }
    //
    // [Route("GetActor/{id}")]
    // [HttpGet]
    // public async Task<Actor> GetActor(int id)
    // {
    //     return await _databaseService.GetActorAsync(id);
    // }
    
    [Route("GetActorByName/{name}")]
    [HttpGet]
    public async Task<IEnumerable<Actor>> GetActor(string name)
    {
        return await _databaseService.GetactorsByNameAsync(name);
    }
 
    #endregion
    
    #region Add

    [Route("AddActor")]
    [HttpPost]
    public async Task<IActionResult> AddActor(ActorViewModel actorViewModel)
    {
        var actor = _mapper.Map<Actor>(actorViewModel);
        var result = await _databaseService.AddActorAsync(actor);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("AddActors")]
    [HttpPost]
    public async Task<IActionResult> AddActors(IEnumerable<ActorViewModel> actorViewModels)
    {
        var actors = _mapper.Map<IEnumerable<Actor>>(actorViewModels);
        var result = await _databaseService.AddActorsAsync(actors);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Update

    [Route("UpdateActor")]
    [HttpPost]
    public async Task<IActionResult> UpdateActor(ActorViewModelWithId actorViewModelWithId)
    {
        var actor = _mapper.Map<Actor>(actorViewModelWithId);
        var result = await _databaseService.UpdateActorAsync(actor);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("UpdateActors")]
    [HttpPost]
    public async Task<IActionResult> UpdateActors(IEnumerable<ActorViewModelWithId> actorViewModelsWithIds)
    {
        var actors = _mapper.Map<IEnumerable<Actor>>(actorViewModelsWithIds);
        var result = await _databaseService.UpdateActorsAsync(actors);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Delete

    [Route("DeleteActor")]
    [HttpPost]
    public async Task<IActionResult> DeleteActor(ActorViewModel actorViewModel)
    {
        var actor = _mapper.Map<Actor>(actorViewModel);
        var result = await _databaseService.RemoveActorAsync(actor);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("DeleteActors")]
    [HttpPost]
    public async Task<IActionResult> DeleteActors(IEnumerable<ActorViewModel> actorViewModels)
    {
        var actors = _mapper.Map<IEnumerable<Actor>>(actorViewModels);
        var result = await _databaseService.RemoveActorsAsync(actors);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
}