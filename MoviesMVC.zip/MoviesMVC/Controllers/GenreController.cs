using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using MoviesMVC.DAL.Models;
using MoviesMVC.DAL.Services;
using MoviesMVC.DAL.ViewModels;
using MoviesMVC.DAL.ViewModelsWithId;

namespace MoviesMVC.Controllers;
[ApiController]
[Route("api/[controller]")]
public class GenreController : Controller
{
    private readonly IMapper _mapper;
    private readonly DatabaseService _databaseService;

    public GenreController(IMapper mapper, DatabaseContext databaseContext)
    {
        _mapper = mapper;
        _databaseService = new DatabaseService(databaseContext);
    }
    
    #region Get

    [Route("GetGenres")]
    [HttpGet]
    public async Task<IEnumerable<Genre>> GetGenre()
    {
        return await _databaseService.GetGenresAsync();
    }

    [Route("GetGenre/{id}")]
    [HttpGet]
    public async Task<Genre> GetGenre(int id)
    {
        return await _databaseService.GetGenreAsync(id);
    }
    [Route("GetGenreByName/{name}")]
    [HttpGet]
    public async Task<IEnumerable<Genre>> GetGenre(string name)
    {
        return await _databaseService.GetGenreByNameAsync(name);
    }
    #endregion
    
    #region Add

    [Route("AddGenre")]
    [HttpPost]
    public async Task<IActionResult> AddActor(GenreViewModel genreViewModel)
    {
        var genre = _mapper.Map<Genre>(genreViewModel);
        var result = await _databaseService.AddGenreAsync(genre);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("AddGenres")]
    [HttpPost]
    public async Task<IActionResult> AddActors(IEnumerable<GenreViewModel> genreViewModels)
    {
        var genres = _mapper.Map<IEnumerable<Genre>>(genreViewModels);
        var result = await _databaseService.AddGenresAsync(genres);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Update

    [Route("UpdateGenre")]
    [HttpPost]
    public async Task<IActionResult> UpdateGenre(GenreViewModelWithId genreViewModelWithId)
    {
        var genre = _mapper.Map<Genre>(genreViewModelWithId);
        var result = await _databaseService.UpdateGenreAsync(genre);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("UpdateGenres")]
    [HttpPost]
    public async Task<IActionResult> UpdateGenres(IEnumerable<GenreViewModelWithId> genreViewModelWithIds)
    {
        var genres = _mapper.Map<IEnumerable<Genre>>(genreViewModelWithIds);
        var result = await _databaseService.UpdateGenresAsync(genres);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
    
    #region Delete

    [Route("Delete")]
    [HttpPost]
    public async Task<IActionResult> DeleteGenres(GenreViewModel genreViewModel)
    {
        var genre = _mapper.Map<Genre>(genreViewModel);
        var result = await _databaseService.RemoveGenreAsync(genre);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    [Route("DeleteGenres")]
    [HttpPost]
    public async Task<IActionResult> DeleteGenres(IEnumerable<GenreViewModel> genreViewModels )
    {
        var genres = _mapper.Map<IEnumerable<Genre>>(genreViewModels);
        var result = await _databaseService.RemoveGenresAsync(genres);
        return result > 0 ? new StatusCodeResult(200) : new StatusCodeResult(500);
    }

    #endregion
}